import os
import json
import asyncio
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands, tasks

logging.basicConfig(level=logging.INFO)
PURGATORY_ID = 1555374207720755333
LOG_CHANNEL_ID = 1561156843156275351
DATA_PATH = Path(os.getenv('PURGATORY_DATA_PATH', 'purgatory.json'))
# Fill in the actual IDs from Server Settings > Roles > Copy Role ID.
# These roles may use /deepestpits and the other moderation commands.
DEEP_ROLE_IDS = {
    int(x) for x in os.getenv('DEEP_ROLE_IDS', '').replace(' ', '').split(',') if x
}
# All roles immune to ordinary purgatory (including the staff roles above).
IMMUNE_ROLE_IDS = {
    int(x) for x in os.getenv('IMMUNE_ROLE_IDS', '').replace(' ', '').split(',') if x
} | DEEP_ROLE_IDS
# Roles allowed to use ordinary purgatory commands, including deep-role staff.
MOD_ROLE_IDS = {
    int(x) for x in os.getenv('MOD_ROLE_IDS', '').replace(' ', '').split(',') if x
} | DEEP_ROLE_IDS

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix='!', intents=intents)
lock = asyncio.Lock()


def read_data():
    try:
        return json.loads(DATA_PATH.read_text())
    except FileNotFoundError:
        return {}


def write_data(data):
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = DATA_PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(DATA_PATH)


def entry_key(guild_id, member_id):
    return f'{guild_id}:{member_id}'


def has_staff(member, deep=False):
    if member.id == member.guild.owner_id:
        return True
    allowed = DEEP_ROLE_IDS if deep else MOD_ROLE_IDS
    return any(role.id in allowed for role in member.roles)


def immune(member):
    return any(role.id in IMMUNE_ROLE_IDS for role in member.roles)


def check_target(actor, target, purg_role):
    guild = actor.guild
    me = guild.me
    if target.id == guild.owner_id or target.id == me.id:
        return 'Cannot punish the server owner or the bot.'
    if target.id == actor.id:
        return 'You cannot punish yourself.'
    if actor.id != guild.owner_id and target.top_role >= actor.top_role:
        return 'The target has an equal or higher role than you.'
    if target.top_role >= me.top_role or purg_role >= me.top_role:
        return 'Move the bot role above the target and Purgatory roles.'
    if not guild.me.guild_permissions.manage_roles:
        return 'The bot needs Manage Roles.'
    return None


async def announce(interaction, message, details):
    # Post public notice where command was invoked, plus dedicated log channel.
    try:
        await interaction.channel.send(message, allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False))
    except (discord.Forbidden, discord.HTTPException, AttributeError):
        pass
    await send_log(interaction.guild, details)


async def send_log(guild, text):
    channel = guild.get_channel(LOG_CHANNEL_ID)
    if channel is None:
        try:
            channel = await guild.fetch_channel(LOG_CHANNEL_ID)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            return
    try:
        await channel.send(text, allowed_mentions=discord.AllowedMentions.none())
    except (discord.Forbidden, discord.HTTPException):
        logging.exception('Failed to send log')


async def place(actor, target, deep=False):
    guild = actor.guild
    role = guild.get_role(PURGATORY_ID)
    if role is None:
        return 'Purgatory role does not exist.'
    error = check_target(actor, target, role)
    if error:
        return error
    if not deep and immune(target):
        return 'This member has an immune role. Only /deepestpits can override immunity.'
    k = entry_key(guild.id, target.id)
    data = read_data()
    if k in data or role in target.roles:
        return 'This member is already in Purgatory.'
    original = [r.id for r in target.roles if r != guild.default_role and not r.managed]
    # Refuse to claim full removal if a managed role cannot be removed.
    if any(r.managed for r in target.roles if r != guild.default_role):
        return 'This member has integration-managed roles that cannot be removed.'
    deadline = datetime.now(timezone.utc) + timedelta(minutes=2) if deep else None
    # Save first, so a crash after role editing doesn't lose the backup.
    data[k] = {'roles': original, 'deep_until': deadline.isoformat() if deadline else None}
    write_data(data)
    try:
        await target.edit(roles=[role], reason=f'{"Deepest pits" if deep else "Purgatory"} by {actor}')
        if deep:
            await target.timeout(deadline, reason=f'Deepest pits by {actor}')
    except (discord.Forbidden, discord.HTTPException) as exc:
        # Keep backup if role edit succeeded but timeout failed, to allow manual release.
        try:
            refreshed = await guild.fetch_member(target.id)
            if role not in refreshed.roles:
                data = read_data()
                data.pop(k, None)
                write_data(data)
        except (discord.HTTPException, discord.Forbidden):
            pass
        return f'Discord rejected the punishment: {exc}. Check roles and /unpurg if needed.'
    return None


async def release(guild, target, actor_label='System'):
    role = guild.get_role(PURGATORY_ID)
    data = read_data()
    k = entry_key(guild.id, target.id)
    saved = data.get(k)
    if not saved:
        return 'No saved roles found for this member.'
    me = guild.me
    if not role or target.top_role >= me.top_role or role >= me.top_role:
        return 'Bot role hierarchy prevents release.'
    restored = []
    for role_id in saved['roles']:
        r = guild.get_role(role_id)
        if r is None:
            continue
        if r.managed or r >= me.top_role:
            return f'Cannot restore {r.name}; fix role hierarchy first.'
        restored.append(r)
    try:
        await target.edit(roles=restored, reason=f'Released from Purgatory by {actor_label}')
        if saved.get('deep_until') and target.is_timed_out():
            await target.timeout(None, reason='Deepest pits ended')
    except (discord.Forbidden, discord.HTTPException) as exc:
        return f'Release failed: {exc}'
    data = read_data()
    data.pop(k, None)
    write_data(data)
    return None


async def authorized(interaction, deep=False):
    if not interaction.guild or not isinstance(interaction.user, discord.Member):
        await interaction.response.send_message('Server only.', ephemeral=True)
        return False
    if not has_staff(interaction.user, deep=deep):
        await interaction.response.send_message('You are not authorized for this command.', ephemeral=True)
        return False
    return True


@bot.tree.command(name='purgatory', description='Send one member to Purgatory')
@app_commands.describe(member='Member to punish')
async def purgatory(interaction: discord.Interaction, member: discord.Member):
    if not await authorized(interaction):
        return
    await interaction.response.defer(ephemeral=True)
    async with lock:
        error = await place(interaction.user, member)
    if error:
        return await interaction.followup.send(error, ephemeral=True)
    await announce(interaction, f'🔥 {member.mention} has been sent to the deepest pits of hell — Purgatory.', f'PURGATORY | User: {member} ({member.id}) | By: {interaction.user} ({interaction.user.id})')
    await interaction.followup.send('Member sent to Purgatory.', ephemeral=True)


@bot.tree.command(name='deepestpits', description='Override immunity: Purgatory and 2-minute timeout')
@app_commands.describe(member='Member to punish')
async def deepestpits(interaction: discord.Interaction, member: discord.Member):
    if not await authorized(interaction, deep=True):
        return
    await interaction.response.defer(ephemeral=True)
    async with lock:
        error = await place(interaction.user, member, deep=True)
    if error:
        return await interaction.followup.send(error, ephemeral=True)
    await announce(interaction, f'🔥 {member.mention} has been condemned to the DEEPEST PITS OF HELL — Purgatory for 2 minutes.', f'DEEPEST PITS | User: {member} ({member.id}) | By: {interaction.user} ({interaction.user.id}) | Duration: 2m')
    await interaction.followup.send('Deepest Pits punishment applied.', ephemeral=True)


@bot.tree.command(name='unpurg', description='Release one member and restore their roles')
async def unpurg(interaction: discord.Interaction, member: discord.Member):
    if not await authorized(interaction):
        return
    await interaction.response.defer(ephemeral=True)
    role = interaction.guild.get_role(PURGATORY_ID)
    if not role or (error := check_target(interaction.user, member, role)):
        return await interaction.followup.send(error if role else 'Purgatory role not found.', ephemeral=True)
    async with lock:
        error = await release(interaction.guild, member, str(interaction.user))
    if error:
        return await interaction.followup.send(error, ephemeral=True)
    await announce(interaction, f'🔓 {member.mention} has escaped the deepest pits of hell — Purgatory.', f'RELEASE | User: {member} ({member.id}) | By: {interaction.user} ({interaction.user.id})')
    await interaction.followup.send('Member released and roles restored.', ephemeral=True)


@bot.tree.command(name='purgatoryrole', description='Send members of a selected role to Purgatory')
async def purgatoryrole(interaction: discord.Interaction, role: discord.Role):
    if not await authorized(interaction):
        return
    await interaction.response.defer(ephemeral=True)
    if role.is_default() or role.id == PURGATORY_ID:
        return await interaction.followup.send('Choose a different role.', ephemeral=True)
    success, skipped = [], 0
    for member in list(role.members):
        async with lock:
            error = await place(interaction.user, member)
        if error:
            skipped += 1
        else:
            success.append(member)
    await announce(interaction, f'🔥 {len(success)} members of **{discord.utils.escape_markdown(role.name)}** have been sent to Purgatory. ({skipped} skipped.)', f'PURGATORY ROLE | Role: {role.name} ({role.id}) | By: {interaction.user} | Sent: {len(success)} | Skipped: {skipped}')
    await interaction.followup.send(f'Sent {len(success)} members; skipped {skipped}.', ephemeral=True)


@bot.tree.command(name='unpurgatoryrole', description='Release members who had this role before Purgatory')
async def unpurgatoryrole(interaction: discord.Interaction, role: discord.Role):
    if not await authorized(interaction):
        return
    await interaction.response.defer(ephemeral=True)
    data = read_data()
    prefix = f'{interaction.guild.id}:'
    ids = [int(k.split(':')[1]) for k, v in data.items() if k.startswith(prefix) and role.id in v['roles']]
    success, skipped = 0, 0
    for user_id in ids:
        try:
            member = await interaction.guild.fetch_member(user_id)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            skipped += 1
            continue
        purg_role = interaction.guild.get_role(PURGATORY_ID)
        if not purg_role or check_target(interaction.user, member, purg_role):
            skipped += 1
            continue
        async with lock:
            error = await release(interaction.guild, member, str(interaction.user))
        if error:
            skipped += 1
        else:
            success += 1
    await announce(interaction, f'🔓 {success} members originally holding **{discord.utils.escape_markdown(role.name)}** have escaped Purgatory. ({skipped} skipped.)', f'RELEASE ROLE | Role: {role.name} ({role.id}) | By: {interaction.user} | Released: {success} | Skipped: {skipped}')
    await interaction.followup.send(f'Released {success}; skipped {skipped}.', ephemeral=True)


class PageSelect(discord.ui.Select):
    def __init__(self, members, page=0):
        self.members = members
        pages = (len(members) + 9) // 10
        # Discord supports max 25 select options; paginate the page selector itself for larger lists.
        start = (page // 25) * 25
        options = [discord.SelectOption(label=f'Page {i + 1}', value=str(i), default=i == page) for i in range(start, min(start + 25, pages))]
        super().__init__(placeholder=f'Page {page + 1} — select a page', options=options)

    async def callback(self, interaction):
        page = int(self.values[0])
        view = PagesView(self.members, page, interaction.user.id)
        await interaction.response.edit_message(embed=make_embed(self.members, page), view=view)


def make_embed(members, page):
    chunk = members[page * 10:(page + 1) * 10]
    desc = '\n'.join(f'• <@{m.id}>' for m in chunk) or 'Nobody in Purgatory.'
    return discord.Embed(title='🔒 Purgatory Members', description=desc, color=discord.Color.red()).set_footer(text=f'Page {page + 1}/{max(1, (len(members) + 9) // 10)} • {len(members)} members')


class PagesView(discord.ui.View):
    def __init__(self, members, page, owner_id):
        super().__init__(timeout=180)
        self.owner_id = owner_id
        self.members = members
        self.page = page
        if members:
            self.add_item(PageSelect(members, page))

    async def interaction_check(self, interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message('Only the person who opened this menu can use it.', ephemeral=True)
            return False
        return True

    @discord.ui.button(label='Previous', style=discord.ButtonStyle.secondary)
    async def previous(self, interaction, button):
        page = max(0, self.page - 1)
        await interaction.response.edit_message(embed=make_embed(self.members, page), view=PagesView(self.members, page, self.owner_id))

    @discord.ui.button(label='Next', style=discord.ButtonStyle.secondary)
    async def next_page(self, interaction, button):
        page = min((len(self.members) - 1) // 10, self.page + 1)
        page = max(0, page)
        await interaction.response.edit_message(embed=make_embed(self.members, page), view=PagesView(self.members, page, self.owner_id))


@bot.tree.command(name='viewpurgatory', description='View Purgatory members with a page dropdown')
async def viewpurgatory(interaction: discord.Interaction):
    if not await authorized(interaction):
        return
    role = interaction.guild.get_role(PURGATORY_ID)
    if role is None:
        return await interaction.response.send_message('Purgatory role not found.', ephemeral=True)
    members = sorted(role.members, key=lambda m: m.display_name.lower())
    await interaction.response.send_message(embed=make_embed(members, 0), view=PagesView(members, 0, interaction.user.id))


@tasks.loop(seconds=15)
async def expire_deepest_pits():
    now = datetime.now(timezone.utc)
    data = read_data()
    for k, saved in list(data.items()):
        until = saved.get('deep_until')
        if not until or datetime.fromisoformat(until) > now:
            continue
        guild_id, user_id = map(int, k.split(':'))
        guild = bot.get_guild(guild_id)
        if guild is None:
            continue
        try:
            member = await guild.fetch_member(user_id)
        except discord.NotFound:
            # User left server: preserve saved data in case they rejoin.
            continue
        except (discord.Forbidden, discord.HTTPException):
            continue
        async with lock:
            error = await release(guild, member, 'Automatic 2-minute timer')
        if error is None:
            await send_log(guild, f'AUTO RELEASE | User: {member} ({member.id}) | Deepest Pits 2 minutes expired')


@expire_deepest_pits.before_loop
async def before_expire():
    await bot.wait_until_ready()


@bot.event
async def on_ready():
    if not expire_deepest_pits.is_running():
        expire_deepest_pits.start()
    if not getattr(bot, '_synced', False):
        await bot.tree.sync()
        bot._synced = True
    logging.info('Logged in as %s', bot.user)


TOKEN = os.getenv('DISCORD_TOKEN')
if not TOKEN:
    raise RuntimeError('Set DISCORD_TOKEN in hosting environment variables.')
bot.run(TOKEN)
