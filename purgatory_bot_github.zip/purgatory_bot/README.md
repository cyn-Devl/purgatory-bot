# Purgatory Discord bot

Python 3.10+; entrypoint `main.py`. Install `requirements.txt`.

## Required environment variables

- `DISCORD_TOKEN`: **new** bot token from Discord Developer Portal; never commit to GitHub.
- `DEEP_ROLE_IDS`: comma-separated role IDs for Head Purgatory Moderator, Senior Moderator, Server Managers, and any higher staff ranks.
- `MOD_ROLE_IDS`: comma-separated role IDs for Purgatory Moderators, Junior Moderator, Moderator, plus any other ordinary authorized moderators. `DEEP_ROLE_IDS` are included automatically.
- `IMMUNE_ROLE_IDS`: comma-separated role IDs for **every** immune role shown in your screenshot: Server Managers, Server Manager Assistants, .bot, Duck secret, Senior moderator, Head purgatory moderator, Bots, akuhple, Moderator, Purgatory moderators, Junior Moderator. `DEEP_ROLE_IDS` are included automatically.
- Optional `PURGATORY_DATA_PATH`: absolute path to persistent storage file (default `purgatory.json`).

## Important

1. Enable **Server Members Intent** in Discord Developer Portal. Invite with `bot` and `applications.commands` scopes. Give bot Manage Roles, Moderate Members, Send Messages and View Channel permissions. Bot role must be above Purgatory and all target roles.
2. The bot refuses to remove integration-managed roles, which Discord does not allow it to remove. Server owner cannot be punished.
3. **Persistent storage is required**: `purgatory.json` is generated at runtime, must survive restarts and deployments, and must not be committed with user data. If host wipes the filesystem, role restoration will fail. Configure a persistent disk or database before production use.
4. Deepest Pits timeout and automatic release is two minutes, checked every 15 seconds while bot is running, or after it restarts. Hosting downtime can delay release. Ordinary Purgatory stays until manually released.
5. Role-based batch commands can take time. Each action is independently checked for immune roles and hierarchy.
6. `/viewpurgatory` displays 10 per page, with dropdown and Previous/Next buttons. Menu expires after 3 minutes; run command again to refresh.
7. Rotate any token previously shared in a chat.
